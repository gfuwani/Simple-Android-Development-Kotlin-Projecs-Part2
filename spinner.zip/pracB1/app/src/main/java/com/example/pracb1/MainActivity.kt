package com.example.pracb1

import android.content.res.Resources
import android.os.Bundle
import android.view.View
import android.view.ViewParent
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Spinner
import android.widget.TextView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class MainActivity : AppCompatActivity() {
    lateinit var tvShow: TextView
    lateinit var spinner: Spinner

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        initializeViews()
        setupListeners()
    }

    private fun initializeViews(){
        tvShow=findViewById(R.id.tvShow)
        spinner=findViewById(R.id.sp)
    }

    private fun setupListeners(){
        val cities = resources.getStringArray(R.array.city_array)
        val adapter= ArrayAdapter(this,android.R.layout.simple_list_item_1,cities)
        spinner.adapter=adapter

        spinner.onItemSelectedListener= object: AdapterView.OnItemSelectedListener{
            override fun onItemSelected(parent: AdapterView<*>?, view: View?,position: Int, id: Long){
                val city= cities[position]
                tvShow.text=city
            }

            override fun onNothingSelected(p0: AdapterView<*>?) {

            }
        }
    }
}