package com.example.pracb8

import android.os.Bundle
import android.view.View
import android.view.ViewGroup
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.BaseAdapter
import android.widget.GridView
import android.widget.ImageView
import android.widget.TextView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class MainActivity : AppCompatActivity() {
    private lateinit var gridView: GridView
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        initializeViews()
        setupListeners()
    }

    private fun initializeViews(){
        gridView=findViewById(R.id.gv)
    }

    private fun setupListeners(){
        val picsInt= intArrayOf(R.drawable.cristiano_ronaldo,R.drawable.lionel_messi,R.drawable.kaka2,R.drawable.beckham,R.drawable.ozil,R.drawable.henry,R.drawable.maldini,R.drawable.ramos,R.drawable.neymar2,R.drawable.mbappe,R.drawable.modric,R.drawable.ronaldinho, R.drawable.salah,R.drawable.zidane)
        val player_names= arrayOf("Ronaldo", "Messi", "Kaka", "Beckham", "Ozil", "Henry", "Maldini", "Ramos", "Neymar", "Mbappe", "Modric", "Ronaldinho", "Salah", "Zidane")

        val adapter= object: BaseAdapter(){
            override fun getCount(): Int= picsInt.size
            override fun getItem(position: Int): Any= picsInt[position]
            override fun getItemId(position: Int): Long = position.toLong()

            override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View {
                val view: View= convertView?: layoutInflater.inflate(R.layout.row_view,parent,false)

                val playerPicture: ImageView = view.findViewById(R.id.ivPicture)
                val playerName: TextView = view.findViewById(R.id.tvName)

                playerPicture.setImageResource(picsInt[position])
                playerName.text= player_names[position]

                return  view
            }
        }

        gridView.adapter= adapter
    }
}