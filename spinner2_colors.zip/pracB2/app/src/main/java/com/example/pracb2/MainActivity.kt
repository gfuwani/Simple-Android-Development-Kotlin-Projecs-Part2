package com.example.pracb2

import android.content.res.TypedArray
import android.graphics.Color
import android.os.Bundle
import android.view.View
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Spinner
import android.widget.TextView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class MainActivity : AppCompatActivity() {
    lateinit var tvShow: TextView
    lateinit var spinner: Spinner

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        initializeViews()
        setupListeners()
    }

    private fun initializeViews(){
        tvShow=findViewById(R.id.tvShow)
        spinner=findViewById(R.id.sp)
    }

    private fun setupListeners(){
        val txtcolors=resources.getStringArray(R.array.color_array)
        val mycolors=resources.getStringArray(R.array.my_colors)

        val adapter= ArrayAdapter(this,android.R.layout.simple_list_item_1,txtcolors)
        spinner.adapter=adapter

        spinner.onItemSelectedListener= object: AdapterView.OnItemSelectedListener{
            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                val color= Color.parseColor(mycolors[position])
                tvShow.setTextColor(color)
            }

            override fun onNothingSelected(p0: AdapterView<*>?) {
                //tvShow.setTextColor(Color.BLACK)
            }
        }
    }
}