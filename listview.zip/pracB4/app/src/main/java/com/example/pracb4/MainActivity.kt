package com.example.pracb4

import android.os.Bundle
import android.view.View
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.ImageView
import android.widget.ListView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class MainActivity : AppCompatActivity() {
    lateinit var imageView: ImageView
    lateinit var listView: ListView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        initializeViews()
        setupListeners()
    }

    private fun initializeViews(){
        imageView=findViewById(R.id.imageView)
        listView=findViewById(R.id.lv)
    }

    private fun setupListeners(){
        val picIds= intArrayOf(R.drawable.harare,R.drawable.bulawayo,R.drawable.gweru)
        val names= resources.getStringArray(R.array.cities_aray)
        val adapter = ArrayAdapter(this,android.R.layout.simple_list_item_1,names)

        listView.adapter=adapter

        listView.setOnItemClickListener{ parent, view, position, id ->
            val selectedCity= names[position]
            val imageResource = picIds[position]
            imageView.setImageResource(imageResource)
        }
    }
}