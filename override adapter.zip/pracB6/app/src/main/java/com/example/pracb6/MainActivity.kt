package com.example.pracb6

import android.os.Bundle
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.ImageView
import android.widget.ListView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.isVisible

class MainActivity : AppCompatActivity() {
    private lateinit var listView: ListView

    val picsInt= intArrayOf(R.drawable.bob_marley,R.drawable.lucky_dube,R.drawable.vybz_kartel)
    val namesList= arrayOf("Bob Marley", "Lucky Dube", "Vybz Kartel")
    val phoneList= arrayOf("1234567890", "", "0213654789")

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        initializeViews()
        setupListeners()
    }

    private fun initializeViews(){
        listView=findViewById(R.id.lv)
    }

    private fun setupListeners(){
        val adapter= object: BaseAdapter(){
            override fun getCount(): Int= namesList.size
            override fun getItem(position: Int): Any= namesList[position]
            override fun getItemId(position: Int): Long= position.toLong()

            override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View{
                val view: View= convertView?: layoutInflater.inflate(R.layout.row_view,parent,false)


                val contactPicture: ImageView = view.findViewById(R.id.ivPicture)
                val contactName: TextView = view.findViewById(R.id.tvName)
                val contactPhone: TextView = view.findViewById(R.id.tvPhone)
                val callButton: ImageView = view.findViewById(R.id.ivPhone)

                contactPicture.setImageResource(picsInt[position])
                contactName.text= namesList[position]
                contactPhone.text=phoneList[position]

                if(contactPhone.text.length>0){
                    contactPhone.isVisible=true
                    callButton.isVisible=true
                }

                else{
                    contactPhone.isVisible=false
                    callButton.isVisible=false
                }

                callButton.setOnClickListener {
                    Toast.makeText(this@MainActivity,"Calling ${phoneList[position]}", Toast.LENGTH_LONG).show()
                }

                return view
            }
        }

        listView.adapter= adapter

        listView.setOnItemClickListener {parent, view, position, int ->
            Toast.makeText(this@MainActivity,"Selecting ${namesList[position]}", Toast.LENGTH_LONG).show()
        }
    }
}