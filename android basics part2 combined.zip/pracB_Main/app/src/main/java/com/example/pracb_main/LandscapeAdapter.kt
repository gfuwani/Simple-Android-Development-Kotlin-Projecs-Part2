package com.example.pracb_main

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.ImageView
import android.widget.TextView

class LandscapeAdapter(context: Context, private val landscapes: List<Landscape>):
    ArrayAdapter<Landscape>(context, R.layout.row_view,landscapes){
    override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
        var itemView =convertView
        val viewHolder: ViewHolder

        if (itemView == null){
            itemView= LayoutInflater.from(context).inflate(R.layout.row_view,parent,false)
            viewHolder= ViewHolder()
            viewHolder.ivLandscapePic= itemView.findViewById(R.id.ivLandscapePic)
            viewHolder.tvLandscapeName= itemView.findViewById(R.id.tvLandscapeName)
            itemView.tag=viewHolder

        }

        else{
            viewHolder= itemView.tag as ViewHolder
        }

        val currentLandscape= landscapes[position]

        viewHolder.ivLandscapePic.setImageResource(currentLandscape.imageResId)
        viewHolder.tvLandscapeName.text=currentLandscape.name

        return itemView!!
    }

    private class ViewHolder{
        lateinit var ivLandscapePic: ImageView
        lateinit var tvLandscapeName: TextView
    }
}