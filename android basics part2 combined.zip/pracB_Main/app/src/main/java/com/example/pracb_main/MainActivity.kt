package com.example.pracb_main

import android.os.Bundle
import android.view.View
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.ImageView
import android.widget.ListView
import android.widget.Spinner
import android.widget.TextView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

data class Landscape(val name: String, val imageResId: Int)

class MainActivity : AppCompatActivity() {
    private lateinit var tvShow: TextView
    private lateinit var spinner: Spinner
    private lateinit var ivclickedLandscape: ImageView
    private lateinit var listView: ListView

    private val cityLandscapeMap= mutableMapOf<String, List<Landscape>>()
    private lateinit var curentCity: String
    private lateinit var currentLandscapes: List<Landscape>

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        initializeData()
        initializeViews()
        setupListeners()
    }


    private fun initializeData(){
        val wenzhou= listOf(
            Landscape("Daluo Mountain", R.drawable.da_luo_shan),
            Landscape("Nanxi River", R.drawable.nan_xi_river),
            Landscape("Yangdang Mountain", R.drawable.yan_dang_shan)
        )

        val hangzhou= listOf(
            Landscape("West Lake", R.drawable.west_lake),
            Landscape("Qianjiang CBD", R.drawable.qian_jiang_cbd),
            Landscape("Lingyin Temple", R.drawable.ling_yin_temple)
        )

        val beijing= listOf(
            Landscape("The Imperial Palace", R.drawable.the_imperial_palace),
            Landscape("Great Wall", R.drawable.great_wall),
            Landscape("Olympic Sports Center", R.drawable.olympic_sports_center)
        )

        cityLandscapeMap["Wenzhou"]= wenzhou
        cityLandscapeMap["Hangzhou"]= hangzhou
        cityLandscapeMap["Beijing"]= beijing

        curentCity="Wenzhou"
        currentLandscapes=wenzhou
    }

    private fun initializeViews(){
        tvShow=findViewById(R.id.tvShow)
        spinner=findViewById(R.id.sp)
        ivclickedLandscape=findViewById(R.id.ivClickedLandscape)
        listView=findViewById(R.id.lv)

        updateDisplayText()
    }

    private fun setupListeners(){
        val cityList= cityLandscapeMap.keys.toList()
        val spinnerAdapter= ArrayAdapter(this,android.R.layout.simple_spinner_item,cityList)
        spinner.adapter=spinnerAdapter

        spinner.setSelection((cityList.indexOf(curentCity)))

        spinner.onItemSelectedListener= object: AdapterView.OnItemSelectedListener{
            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                val selectedCity= parent?.getItemAtPosition(position).toString()
                curentCity=selectedCity
                currentLandscapes= cityLandscapeMap[selectedCity]?: emptyList()

                updateListView()
                updateDisplayText()
            }

            override fun onNothingSelected(parent: AdapterView<*>?) {}
        }

        listView.onItemClickListener= AdapterView.OnItemClickListener{parent,view,position,id ->
            val selectedLandscape= currentLandscapes[position]
            tvShow.text= "$curentCity - ${selectedLandscape.name}"
            ivclickedLandscape.setImageResource(selectedLandscape.imageResId)
        }
    }

    private fun updateListView(){
        val adapter= LandscapeAdapter(this, currentLandscapes)
        listView.adapter=adapter
    }

    private fun updateDisplayText(){
        if (currentLandscapes.isNotEmpty()){
            tvShow.text="$curentCity - ${currentLandscapes[0].name}"
            ivclickedLandscape.setImageResource(currentLandscapes[0].imageResId)
        }
    }
}